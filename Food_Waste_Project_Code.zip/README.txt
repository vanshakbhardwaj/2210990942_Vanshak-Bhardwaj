
Food Waste Prediction Using Machine Learning Models

Project Files:
1. food_waste_prediction.py
2. sample_food_waste_dataset.csv

Libraries Used:
- Pandas
- NumPy
- Scikit-learn

Model Used:
- Random Forest Regressor

Run Command:
python food_waste_prediction.py
